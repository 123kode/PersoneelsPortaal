function Plattegrond() {
    return (
        <div className="plattegrond">
            <img
                src="/images/grondplan.png"
                alt="Grondplan commissariaat"
            />
        </div>
    );
}

export default Plattegrond;